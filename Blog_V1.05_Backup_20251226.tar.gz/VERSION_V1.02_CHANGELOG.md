# 项目版本更新日志 - V1.02

**更新日期**: 2025年1月  
**项目版本**: V1.02  
**基于版本**: V1.01

---

## 📋 版本信息

- **项目版本**: V1.02
- **Hexo 版本**: 6.3.0
- **主题**: paper
- **更新类型**: 字体大小优化与标题显示优化

---

## ✨ 版本优化说明

### 1. 字体大小统一优化

**问题描述**：
- 正文字体大小（1.4rem/14px）偏小，不利于阅读
- 不同元素的字体大小不统一，影响视觉一致性

**优化内容**：
- ✅ 将所有文本元素的字体大小统一为 **1.6rem (16px)**
- ✅ 统一行高为 **2.3rem**，保持良好的行距
- ✅ 优化以下元素的字体大小：
  - 正文（p, li, ol, table, code）
  - 侧边栏（sidebar）
  - 位置栏（location-bar）
  - 文章摘要（posts-item__excerpt）
  - 上一页/下一页按钮（pre-next/pre-button）
  - 页脚（footer）
  - 标签（post__tags）
  - 日期（post__date）

**修改文件**：
- `themes/paper/source/css/post.styl`
- `themes/paper/source/css/includes/_sidebar.styl`
- `themes/paper/source/css/includes/_location-bar.styl`
- `themes/paper/source/css/includes/_posts.styl`
- `themes/paper/source/css/includes/_pre-next.styl`
- `themes/paper/source/css/includes/_footer.styl`

**字体大小对比**：
- **V1.01**: 1.4rem (14px)
- **V1.02**: 1.6rem (16px) ⬆️ 提升 14.3%

---

### 2. 浏览器标签页标题优化

**问题描述**：
- 浏览器标签页标题需要显示更完整的网站名称
- 但页面头部链接需要保持简洁

**优化内容**：
- ✅ 浏览器标签页标题显示为 "Jopus的博客"
- ✅ 页面头部链接保持显示 "Jopus"
- ✅ 实现方式：修改 `getPageTitle()` 函数，在标题后添加 "的博客" 后缀

**修改文件**：
- `themes/paper/layout/includes/layout.pug`

**效果**：
- 浏览器标签页：`<title>Jopus的博客</title>`
- 页面头部：`<a href="/">Jopus</a>`

---

## 📝 技术细节

### 字体大小设置

所有相关元素统一使用：
```styl
font-size: 1.6rem
line-height: 2.3rem
```

### 标题显示逻辑

```pug
- let getPageTitle = function() {
-     let pageTitle = ''
-     let siteTitle = config.title + '的博客'
-     // ... 其他逻辑
-     if (pageTitle == '') return siteTitle
-      pageTitle += ' - ' + siteTitle
-     return pageTitle
- }
```

---

## 🔄 与 V1.01 的差异

### 新增功能
- 浏览器标签页标题优化（显示 "Jopus的博客"）

### 修改内容
- 所有文本元素字体大小从 1.4rem 调整为 1.6rem
- 统一行高为 2.3rem
- 标题生成逻辑优化

### 保持不变
- Hexo 核心版本：6.3.0
- 所有依赖包版本
- 主要配置文件结构
- 主题核心功能
- 移动端分页优化（V1.01 的功能）

---

## 📦 当前配置状态

### 字体配置
- **正文字体大小**: 1.6rem (16px)
- **行高**: 2.3rem
- **字符间距**: 0 (默认值)

### 标题配置
- **浏览器标签页标题**: "Jopus的博客"
- **页面头部显示**: "Jopus"
- **站点标题配置**: "Jopus"

---

## 🚀 升级说明

从 V1.01 升级到 V1.02：

1. **无需修改依赖**：所有 npm 包版本保持不变
2. **样式文件**：字体大小相关样式已更新
3. **模板文件**：标题生成逻辑已优化

**升级步骤**：
```bash
# 清理缓存
npx hexo clean

# 重新生成静态文件
npx hexo generate

# 启动服务器查看效果
npx hexo server
```

---

## 📌 注意事项

1. **字体大小**：所有文本元素现在统一使用 1.6rem，提升了可读性
2. **标题显示**：浏览器标签页和页面头部显示不同的文本，这是有意设计的
3. **字符间距**：当前使用默认值（0），如需调整可添加 `letter-spacing` 属性

---

## 🔗 相关文件

### 修改的文件
- `themes/paper/source/css/post.styl` - 正文字体大小
- `themes/paper/source/css/includes/_sidebar.styl` - 侧边栏字体大小
- `themes/paper/source/css/includes/_location-bar.styl` - 位置栏字体大小
- `themes/paper/source/css/includes/_posts.styl` - 文章摘要、标签、日期字体大小
- `themes/paper/source/css/includes/_pre-next.styl` - 上一页/下一页按钮字体大小
- `themes/paper/source/css/includes/_footer.styl` - 页脚字体大小
- `themes/paper/layout/includes/layout.pug` - 标题生成逻辑

### 参考文档
- `VERSION_V1.01_CHANGELOG.md` - V1.01 版本更新日志
- `VERSION_V1.0_BACKUP.md` - V1.0 版本备份文档

---

**文档创建时间**: 2025年1月  
**最后更新**: 2025年1月

