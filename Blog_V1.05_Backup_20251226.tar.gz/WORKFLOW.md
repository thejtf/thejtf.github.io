# Hexo 博客工作流程说明

## 📋 分支说明

### source 分支（源代码分支）
- **用途**：存储 Hexo 源代码
- **内容**：
  - 配置文件（`_config.yml`）
  - 文章源文件（`source/_posts/`）
  - 主题文件（`themes/`）
  - 其他源代码文件

### master 分支（部署分支）
- **用途**：存储生成的静态文件，用于 GitHub Pages
- **内容**：由 `hexo generate` 生成的 HTML、CSS、JS 等静态文件
- **更新方式**：通过 `hexo deploy` 自动更新

## 🔄 正确的工作流程

### 1. 编辑文章和配置

在 `source` 分支进行所有编辑工作：

```bash
# 确保在 source 分支
git checkout source

# 创建新文章
npx hexo new "文章标题"

# 编辑文章（使用你喜欢的编辑器）
vim source/_posts/文章标题.md

# 本地预览
npx hexo server
# 访问 http://localhost:4000 查看效果
```

### 2. 提交源代码更改

```bash
# 添加更改
git add .

# 提交更改
git commit -m "添加新文章：文章标题"

# 推送到远程 source 分支
git push origin source
```

### 3. 部署到 GitHub Pages

```bash
# 生成静态文件并部署到 master 分支
npx hexo deploy

# 或者使用 npm scripts
npm run deploy
```

这个命令会：
1. 自动生成静态文件（`hexo generate`）
2. 将静态文件推送到 `master` 分支
3. GitHub Pages 会自动更新网站

## ⚠️ 重要提示

### ❌ 不要这样做：

1. **不要手动合并 source 到 master**
   ```bash
   # ❌ 错误做法
   git checkout master
   git merge source
   ```

2. **不要直接在 master 分支编辑**
   - master 分支应该只包含生成的静态文件
   - 所有编辑都应该在 source 分支进行

3. **不要手动修改 master 分支的内容**
   - master 分支的内容会被 `hexo deploy` 覆盖

### ✅ 正确做法：

1. **所有编辑在 source 分支进行**
2. **使用 `hexo deploy` 更新 master 分支**
3. **定期提交源代码到 source 分支**

## 🔀 如果需要同步远程更改

### 从远程 source 分支拉取更新

```bash
git checkout source
git pull origin source
```

### 从远程 master 分支获取最新部署

通常不需要手动操作，但如果需要：

```bash
# 查看 master 分支的部署历史（只读）
git fetch origin master
git log origin/master --oneline -10
```

## 📝 完整示例流程

```bash
# 1. 切换到 source 分支
git checkout source

# 2. 创建新文章
npx hexo new "我的新文章"

# 3. 编辑文章
vim source/_posts/我的新文章.md

# 4. 本地预览
npx hexo server
# 在浏览器中查看 http://localhost:4000

# 5. 提交源代码
git add .
git commit -m "添加新文章：我的新文章"
git push origin source

# 6. 部署到 GitHub Pages
npx hexo deploy

# 完成！网站已更新
```

## 🎯 总结

- **源代码** → `source` 分支（手动提交）
- **静态文件** → `master` 分支（通过 `hexo deploy` 自动更新）
- **不要合并分支**，使用 `hexo deploy` 来更新网站

